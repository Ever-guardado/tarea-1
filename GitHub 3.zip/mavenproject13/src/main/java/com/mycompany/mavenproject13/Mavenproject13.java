/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject13;

/**
 *
 * @author USUARIO
 */
public class Mavenproject13 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
